[hr]
[center][color=red][size=16pt][b]SMF Garage MOD[/b][/size][/color][/center]

All credits to Rasco

SMF Garage is a Vehicle Management System (VMS) for Simple Machines Forum. This extension adds the capability for users to create a vehicle profile to be a associated with their user profile on an SMF forum.

Each vehicle profile is capable of maintaining vehicle details, images, videos, modifications, dynoruns, quartermile runs, insurance premiums, lap times, and service history.

In addition to vehicle profiles, SMF Garage is also capable of storing business profiles to help track the history of a vehicle. Retail shops, repair garages, manufacturers, and insurance agencies can all be stored and associated with vehicle profiles


This is a small update to allow this MOD to install cleanly in SMF 2.0.9+

[b]Compatibility:[/b]
	- SMF 2.1 and 2.0.9 and higher

[b]Languages:[/b]
     - English
     - English UTF-8


[center][b]License:[/b]
This mod is licensed under [url=https://opensource.org/licenses/BSD-3-Clause]BSD 3 Clause[/url] (check the included SMF_Garage_License.txt)[/center]