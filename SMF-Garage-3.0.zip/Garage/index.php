<?php
header("Location: ../index.php?action=garage")
?>